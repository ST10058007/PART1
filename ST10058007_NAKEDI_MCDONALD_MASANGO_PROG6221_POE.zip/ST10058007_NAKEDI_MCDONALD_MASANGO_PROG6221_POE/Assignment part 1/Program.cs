﻿using System;


namespace RecipeApp
{
    class RecipeProgram
    {
        static void Main(string[] args)
        {
                Recipe recipe = new Recipe();

            while (true)
            {
                //prompt the user to select what he desires to do.
                Console.WriteLine("select any option below:");
                Console.WriteLine("1. Enter recipe details");
                Console.WriteLine("2. Display recipe");
                Console.WriteLine("3. Scale recipe");
                Console.WriteLine("4. Reset quantities");
                Console.WriteLine("5. Clear recipe");
                Console.WriteLine("6. Exit");

                string input = Console.ReadLine();
                Console.WriteLine();

                switch (input)
                {
                    case "1":
                        recipe.EnterDetails();
                        break;
                    case "2":
                        recipe.Display();
                        break;
                    case "3":
                        recipe.Scale();
                        break;
                    case "4":
                        recipe.ResetQuantities();
                        break;
                    case "5":
                        recipe.Clear();
                        break;
                    case "6":
                        return;
                    default:
                        Console.WriteLine("Invalid command.");
                        break;
                }
            }
        }
    }

    class Recipe
    {
        private List<Ingredient> ingredients;
        private List<string> steps;

        public Recipe()
        {
            ingredients = new List<Ingredient>();
            steps = new List<string>();
        }

        public void EnterDetails()//prompt the user to enter details.
        {
            ingredients.Clear();
            steps.Clear();

            Console.Write("Enter the number of ingredients: ");// prompt the user to enter number of ingredients 
            int numIngredients = int.Parse(Console.ReadLine());

            for (int i = 0; i < numIngredients; i++)
            {
                Console.Write($"Enter the name of ingredient {i + 1}: ");
                string name = Console.ReadLine();

                Console.Write($"Enter the quantity of {name}: ");
                double quantity = double.Parse(Console.ReadLine());

                Console.Write($"Enter the unit of measurement for {name}: ");
                string unit = Console.ReadLine();

                ingredients.Add(new Ingredient(name, quantity, unit));
            }

            Console.Write("Enter the number of steps: ");
            int numSteps = int.Parse(Console.ReadLine());

            for (int i = 0; i < numSteps; i++)
            {
                Console.Write($"Enter step {i + 1}: ");
                string step = Console.ReadLine();

                steps.Add(step);
            }

            Console.WriteLine("Recipe details entered.");
            Console.WriteLine();
        }

        public void Display()
        {
            Console.WriteLine("Ingredients:");
            foreach (Ingredient ingredient in ingredients)
            {
                Console.WriteLine($"- {ingredient.Quantity} {ingredient.Unit} {ingredient.Name}");
            }
            Console.WriteLine();

            Console.WriteLine("Steps:");
            foreach (string step in steps)
            {
                Console.WriteLine($"- {step}");
            }
            Console.WriteLine();
        }

        public void Scale()
        {
            Console.Write("Enter the scaling factor (0.5, 2, or 3): ");
            double fac = double.Parse(Console.ReadLine());

            foreach (Ingredient ingredient in ingredients)
            {
                ingredient.ScaleQuantity(fac);
            }

            Console.WriteLine("Recipe scaled.");
            Console.WriteLine();
        }

        public void ResetQuantities()
        {
            foreach (Ingredient ingredient in ingredients)
            {
                ingredient.ResetQuantity();
            }

            Console.WriteLine("Quantities reset.");
            Console.WriteLine();
        }

        public void Clear()
        {
            ingredients.Clear();
            steps.Clear();

            Console.WriteLine("Recipe cleared.");
            Console.WriteLine();
        }
    }

    class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        private double originalQuantity;

        public Ingredient(string name, double quantity, string unit)
        {
            Name = name;
        }

        internal void ResetQuantity()
        {
            throw new NotImplementedException();
        }

        internal void ScaleQuantity(double factor)
        {
            throw new NotImplementedException();
        }
    }
}